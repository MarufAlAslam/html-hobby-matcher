$('.slider').slick({
    autoplay: true,
    autoplaySpeed: 2000,
    arrows: false,
});